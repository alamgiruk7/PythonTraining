''' Write a program to read through a file and print the contents of the file [line by line] all in UPPER CASE  '''

def printContent(file):
    try:
        # Read content from the file
        f = open(file)
        content = f.read()
        content = content.upper()
        count = 1
        for line in content:
            if line.endswith("\n"):
                count += 1

        print(f"Total Lines: {count}")
        
        # Write the Upper Case content to a new file.
        fw = open("New_File.txt", "w")
        fw.write(content)
    
    except:
        print("File Not Found!")
    


file_path = "Old_File.txt"

printContent(file_path)